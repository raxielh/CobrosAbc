<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class Interes extends Model
{
	protected $fillable = ['numero','cobro_id'];
}
