<?php $__env->startSection('content'); ?>
<style media="screen">
  .mdl-button--fab{
    color: #fff;
    background: rgb(68, 220, 80);
  }
</style>
<h3 style="margin: 6px;color: #676767;font-weight: 200;">Pago Prestamo <?php if(currentUser() == 1): ?><a href="<?php echo e(url('prestamo_ordenar')); ?>" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect"><i class="material-icons">vertical_align_center</i>Ordenar</a><?php endif; ?></h3>

  <table id="tbl_barrio" style="width:100% !important">
    <thead style="background: #37474f;">
      <tr>
        <th></th>
        <th  style="color:#fff">Cliente</th>
        <th  style="color:#fff">Identificacion</th>
        <th  style="color:#fff">Monto</th>
        <th  style="color:#fff">Interes</th>
        <th  style="color:#fff">Valor Prestamo</th>
        <th  style="color:#fff">Tiempo</th>
        <th  style="color:#fff">Cuota</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data['datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th>
          <a class="mdl-button mdl-js-button mdl-button--fab" href="<?php echo e(url('pago')); ?>/<?php echo e($value->ide); ?>">
            <i class="material-icons">account_balance_wallet</i>
          </a>
        </th>
        <th><?php echo e($value->nombre); ?></th>
        <th><?php echo e($value->identificacion); ?></th>
        <th><?php echo e($value->mascara_monto); ?></th>
        <th><?php echo e($value->interes); ?></th>
        <th><?php echo e($value->valor_prestamo); ?></th>
        <th><?php echo e($value->tiempo); ?></th>
        <th><?php echo e($value->cuota); ?></th>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<script type="text/javascript">
$(function() {
  $("#pago").addClass("active");
  cargar();
});

function cargar(){
  var table=$('#tbl_barrio').DataTable( {
      "responsive": true,
      "ordering": false
  });
}


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>