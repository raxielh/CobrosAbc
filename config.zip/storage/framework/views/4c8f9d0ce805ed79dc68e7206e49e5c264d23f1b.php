<?php $__env->startSection('content'); ?>
<style type="text/css">
<?php if(currentUser() == 1): ?>
  .oculto{
    display: block;
  }
<?php else: ?>
  .oculto{
    display: none;
  }
<?php endif; ?>
</style>
<h3 style="margin: 6px;color: #676767;font-weight: 200;"><a href="<?php echo e(route('pago.index')); ?>"><i class="material-icons" style="color: #263238;">arrow_back</i></a> Pagos Prestamo</h3>
<div class = "mdl-grid">
    <div class = "mdl-cell mdl-cell--9-col mdl-cell--12-col-phone graybox">
        <h4 style="margin: 6px;color: #676767;font-weight: 200;text-align:center">Pagar y historial de pago</h4>
        <form action="<?php echo e(url('pago')); ?>" method="post" id="save_barrio">
          <?php echo csrf_field(); ?>

          <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label ">
              <label for="input_text" class="mdl-textfield__label">Monto</label>
              <?php $__currentLoopData = $data['datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <input type="hidden" id="monto" name="monto" required="" value="<?php echo e($value->cuota_m); ?>" />
              <input type="text" class="mdl-textfield__input" id="mascara_monto" name="" value="<?php echo e($value->cuota_m); ?>" required="" />
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label ">
              <label for="input_text" class="mdl-textfield__label">Referencia</label>
              <input type="text" class="mdl-textfield__input"  name="referencia" value="" />
          </div>
          <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label ">
              <label for="input_text" class="mdl-textfield__label">Fecha</label>
              <input type="date" class="mdl-textfield__input"  name="fecha" value="<?php echo e(date('Y-m-d')); ?>" required="" />
          </div>
          <input type="hidden" name="prestamo" value="<?php echo e($data['datos'][0]->ide); ?>">
          <button type="submit" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
            Pagar
          </button>
        </form>
        <table id="tbl_barrio" class="table display responsive no-wrap" style="width:100% !important">
          <thead>
              <tr>
                  <th>Monto</th>
                  <th>Fecha</th>
                  <th>Refrencia</th>
                  <th>Cobrador</th>
                  <th></th>
              </tr>
          </thead>
        </table>
    </div>
    <div class = "mdl-cell mdl-cell--3-col mdl-cell--12-col-phone graybox">
        <h4 style="margin: 6px;color: #676767;font-weight: 200;text-align:end">Detalle de prestamo</h4>

          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Cliente:</strong> <?php echo e($data['datos'][0]->nombre); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Identificacion:</strong> <?php echo e($data['datos'][0]->identificacion); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Monto:</strong> <?php echo e(number_format($data['datos'][0]->monto)); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Interes:</strong> <?php echo e($data['datos'][0]->interes); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Valor Prestamo:</strong>  <?php echo e($data['datos'][0]->valor_prestamo); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Tiempo:</strong> <?php echo e($data['datos'][0]->tiempo); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Cuota:</strong> <?php echo e($data['datos'][0]->cuota); ?></p>
         <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Pagado:</strong> <?php echo e(number_format($data['pp'][0]->pagado)); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Debe:</strong> <?php echo e(number_format(($data['datos'][0]->monto)-($data['pp'][0]->pagado))); ?></p>
          <p style="margin:0px 0px 6px;text-align:end;font-size:20px;font-weight: 300;"><strong>Cuotas faltantes:</strong> <?php echo e($data['datos'][0]->tiempo-$data['pp'][0]->restantes); ?></p>
    </div>
 </div>

<script type="text/javascript">
$(function() {
            cargar();
  $("#pago").addClass("active");
  $( "#mascara_monto" ).keyup(function() {
    $("#monto").val(QuitarMoneda($( "#mascara_monto" ).val()));
    $("#mascara_monto").val(Moneda($( "#mascara_monto" ).val()));
  });
  $("#save_barrio").submit(function(e) {
    e.preventDefault();
    $(".load").show();
    var form = $(e.target);
    var datos = $("#save_barrio").serialize();
    $.ajax(
      {
        type: "POST",
        url: form.attr("action"),
        data:datos,
        success: function (data)
        {
          $(".load").hide();
          $("#save_barrio")[0].reset();
          mensaje(data);
          location.reload(true);
        },
        error: function(jqXHR, text, error)
        {
          mensaje(data);
        }
      }
    );
    return false;
  });
});

function cargar(){
  var table=$('#tbl_barrio').DataTable( {
      "destroy": true,
      "processing": true,
      ajax: '<?php echo e(url('pago_get')); ?>/<?php echo e($data['datos'][0]->ide); ?>',
      columns: [
          {data: 'mascara_monto'},
          {data: 'fecha'},
          {data: 'referencia'},
          {data: 'nombre'},
          {data: 'action2', name: 'action2', orderable: false, searchable: false},
      ],
      columnDefs: [
          { width: 110, targets: 4 },
      ]
  });
  table
      .column( '1:visible' )
      .order( 'desc' )
      .draw();
}

function borrar(id){
  $.confirm({
      title: 'Confirmar!',
      content: 'Estas seguro!',
      buttons: {
          Si: function () {
            $(".load").show();
            $.ajax({
              method: "POST",
              url: "<?php echo e(url('pago')); ?>/"+id,
              data: { _token: "<?php echo e(csrf_token()); ?>",_method: "DELETE" }
            }).done(function( data ) {
              $(".load").hide();
              mensaje(data);
              location.reload(true);
            });
          },
          Cancelar: function () {
            $(".load").hide();
          },
      }
  });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>