<?php $__env->startSection('content'); ?>
    <h4 style="margin: 6px;color: #676767;font-weight: 200;">Capital Base: <?php echo e(($data['datos'][0]["total"])); ?> </h4>
	
	<script type="text/javascript">
	$(function() {
	  $("#home").addClass("active");
	});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>