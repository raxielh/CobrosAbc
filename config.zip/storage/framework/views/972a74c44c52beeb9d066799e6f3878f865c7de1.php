<?php $__env->startSection('content'); ?>
<h3 style="margin: 6px;color: #676767;font-weight: 200;"><a href="<?php echo e(route('pago.index')); ?>"><i class="material-icons" style="color: #263238;">arrow_back</i></a> Ordenar prestamos</h3>

  <table id="tbl_barrio" class="mdl-data-table mdl-js-data-table" style="width:100% !important">
    <thead style="background: #37474f;">
      <tr>
        <th></th>
        <th  style="color:#fff">Cliente</th>
        <th  style="color:#fff">Identificacion</th>
        <th  style="color:#fff">Monto</th>
        <th  style="color:#fff">Interes</th>
        <th  style="color:#fff">Valor Prestamo</th>
        <th  style="color:#fff">Tiempo</th>
        <th  style="color:#fff">Cuota</th>
        <th  style="color:#fff">Fecha</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $data['datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th>
          <a href="<?php echo e(url('prestamo_ordenar_minus')); ?>/<?php echo e($value->ide); ?>"><i class="material-icons" style="color: #263238;">arrow_upward</i></a>
          <a href="<?php echo e(url('prestamo_ordenar_plus')); ?>/<?php echo e($value->ide); ?>"><i class="material-icons" style="color: #263238;">arrow_downward</i></a>
        </th>
        <th><?php echo e($value->nombre); ?></th>
        <th><?php echo e($value->identificacion); ?></th>
        <th><?php echo e($value->mascara_monto); ?></th>
        <th><?php echo e($value->interes); ?></th>
        <th><?php echo e($value->valor_prestamo); ?></th>
        <th><?php echo e($value->tiempo); ?></th>
        <th><?php echo e($value->cuota); ?></th>
        <th><?php echo e($value->fecha); ?></th>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<script type="text/javascript">
$(function() {
  $("#pago").addClass("active");
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>